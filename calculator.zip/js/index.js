var $keys = document.getElementsByTagName('th');
var register = [];
var operators = ['*', '/', '+', '-'];
var special_op = ['%', '+/-'];
var $op_display = document.getElementById('operator');
var $sign_display = document.getElementById('sign');
var $display = document.getElementById('display');
var calculate = {
  '*': function(x, y) {
    return x * y
  },
  '/': function(x, y) {
    return x / y
  },
  '+': function(x, y) {
    return x + y
  },
  '-': function(x, y) {
    return x - y
  }
};
//functions
var initialize = function() {
  register = [];
  $display.innerHTML = '';
  $op_display.innerHTML = '';
  $sign_display.innerHTML = '';
};
var decimal = function(input) {
  if ($display.innerHTML.indexOf('.') !== -1) {
    //ignore
  } else {
    $display.innerHTML += input;
  }
};
var special_operator = function(input) {
  if (isNaN($display.innerHTML) === true) {
    //ignore
  } else {
    if (input === '%') {
      $display.innerHTML *= .01;
    } else if (input === '+/-') {
      $display.innerHTML *= -1;
    } else {
      //ignore
    }
  }
};
var operator = function(input) {
  if ($display.innerHTML === '') {
    //if display is empty, ignore operator
  } else {
    $op_display.innerHTML = input;
    var $last_num = $display.innerHTML;
    if (isNaN($last_num) === true) {
      alert('ERR');
    } else {
      register.push($display.innerHTML);
      register.push(input);
      $display.innerHTML = '';
    }
  }
};
var eval = function() {
  try {
    register.push($display.innerHTML);
    $sign_display.innerHTML = $input;
    $op_display.innerHTML = '';

    for (var n = 0; n < operators.length; n++) {
      var index = register.indexOf(operators[n]);
      var answer;
      if (index !== -1) {
        answer = calculate[operators[n]](parseFloat(register[index - 1]), parseFloat(register[index + 1]));
        register.splice(index - 1, 3, answer);

      }
    }
    result = parseFloat(register).toFixed(3);
    register = [];
    $display.innerHTML = result;

  } catch (e) {
    alert(e);
  }
};
//start
initialize();
for (var i = 0; i < $keys.length; i++) {
  $keys[i].addEventListener('click', function() {
    $input = this.innerHTML;

    //identify whether input key is a number or not
    if (isNaN($input) === true) {
      //identify what type of NaN
      if ($input === 'AC') {
        initialize();
      } else if ($input === '.') {
        decimal($input);
      } else if ($input === '=') {
        $sign_display.innerHTML = $input;
        $op_display.innerHTML = '';
        if ($display.innerHTML === '') {

        } else {
          eval();
        }
      } else if (special_op.indexOf($input) !== -1) {
        special_operator($input);
      } else if (operators.indexOf($input) !== -1) {
        operator($input);
      } else {
        alert('ERR');
      }
    } else {
      $display.innerHTML += $input;
    }

  });
}