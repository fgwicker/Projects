A Pen created at CodePen.io. You can find this one at https://codepen.io/fgwicker/pen/wWQKXa.

 A basic calculator written in Sass and javascript